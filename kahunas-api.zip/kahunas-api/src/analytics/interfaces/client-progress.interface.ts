export interface ClientProgress {
  totalSessions: number;
  completedSessions: number;
  upcomingSessions: number;
  progressRate: number;
}
