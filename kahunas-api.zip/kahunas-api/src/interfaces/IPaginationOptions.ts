export interface IPaginationOptions {
  page?: string;
  limit?: string;
}
